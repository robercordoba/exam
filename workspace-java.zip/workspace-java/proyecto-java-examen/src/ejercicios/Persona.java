package ejercicios;

import java.util.Date;

public class Persona {
	public enum TipoDoc{
		DNI, LIBRETACIVICA;
	}
	
	private TipoDoc tipoDoc; 
	private Integer nroDoc;
	private String nombre;
	private String apellido;
	private Date fechaNacimiento;
	
	public Persona() {
		// TODO Auto-generated constructor stub
	}
	
	public TipoDoc getTipoDoc() {
		return tipoDoc;
	}

	public void setTipoDoc(TipoDoc tipoDoc) {
		this.tipoDoc = tipoDoc;
	}

	public Integer getNroDoc() {
		return nroDoc;
	}

	public void setNroDoc(Integer nroDoc) {
		this.nroDoc = nroDoc;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public Date getFechaNacimiento() {
		return fechaNacimiento;
	}

	public void setFechaNacimiento(Date fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}

	@Override
	public String toString() {
		return "Persona [tipoDoc=" + tipoDoc + ", nroDoc=" + nroDoc + ", nombre=" + nombre + ", apellido=" + apellido
				+ ", fechaNacimiento=" + fechaNacimiento + "]";
	}



}
