﻿----EJERCICIOS
-- SOLO ES REQUERIDO REALIZAR LOS EJERCICIOS DE COMPLEJIDAD BAJA, realizar los demas ejercicios serán puntos extras para la evaluación del examen.


--- EJERCICIO 1 - COMPLEJIDAD BAJA: 
--Realizar una consulta para consultar todos los alumnos existentes, mostrar: TipoDoc, Documento, Nombre, Apellido, Legajo.
SELECT P.TipoDoc, P.Documento, P.Nombre, P.Apellido, A.Legajo
FROM PUBLIC.ALUMNO A,  PUBLIC.PERSONA P
WHERE A.IDPERSONA = P.IDENTIFICADOR;

--- EJERCICIO 2 - COMPLEJIDAD BAJA: 
--Realizar una consulta para consultar todas las carreras a la que un alumno esta inscripto, mostrar: Legajo, nombre, apellido, nombre carrera, fechainscripcioncarrera
--ordenado por legajo descendiente
SELECT A.Legajo, P.nombre, P.apellido, C.nombre "Nombre Carrera", I.fechainscripcion "Fecha Inscripcion Carrera"
FROM PUBLIC.INSCRIPCIONES_CARRERA I,
     PUBLIC.CARRERA C,            
     PUBLIC.ALUMNO A,  
     PUBLIC.PERSONA P
WHERE I.IDCARRERA = C.IDENTIFICADOR
      AND I.IDALUMNO = A.IDENTIFICADOR
      AND A.IDPERSONA = P.IDENTIFICADOR
ORDER BY A.LEGAJO DESC;

--- EJERCICIO 3 - COMPLEJIDAD MEDIA: 
--Realizar una consulta para consultar la cantidad de inscriptos por curso, mostrando: nombre carrera, nombre curso, cantidad inscriptos, cupo máximo por curso
SELECT CA.NOMBRE "Nombre Carrera", C.NOMBRE "Nombre Curso", COUNT( I.IDCURSO)  "Cantidad Inscriptos", C.CUPOMAXIMO
FROM PUBLIC.INSCRIPCIONES_CURSO I,
     PUBLIC.CURSO C,
     PUBLIC.CARRERA CA
WHERE I.IDCURSO = C.IDENTIFICADOR
       AND C.IDCARRERA = CA.IDENTIFICADOR
GROUP BY I.IDCURSO, CA.NOMBRE , C.NOMBRE, C.CUPOMAXIMO;

--- EJERCICIO 4 - COMPLEJIDAD ALTA: 
--Sobre la consulta anterior (copiar y pegarla y modificarla) modificar la sql para que la consulta retorne solo los cursos cuya cantidad de inscripciones 
--supera su cupo maximo
SELECT CA.NOMBRE "Nombre Carrera", C.NOMBRE "Nombre Curso", COUNT( I.IDCURSO)  "Cantidad Inscriptos", C.CUPOMAXIMO
FROM PUBLIC.INSCRIPCIONES_CURSO I,
            PUBLIC.CURSO C,
            PUBLIC.CARRERA CA
WHERE I.IDCURSO = C.IDENTIFICADOR
       AND C.IDCARRERA = CA.IDENTIFICADOR
GROUP BY I.IDCURSO, CA.NOMBRE , C.NOMBRE, C.CUPOMAXIMO
HAVING COUNT( I.IDCURSO) > C.CUPOMAXIMO ;

--- EJERCICIO 5 -  COMPLEJIDAD BAJA: 
-- actualizar todos las cursos que posean anio 2018 y cuyo cupo sea menor a 5, y actualizar el cupo de todos ellos a 10.
UPDATE PUBLIC.CURSO 
   SET  CUPOMAXIMO = 10
WHERE ANIO = 2018
  AND CUPOMAXIMO < 5;
--UPDATE COUNT 
--  2  


--- EJERCICIO 6 -  COMPLEJIDAD ALTA: 
-- actualizar todas las fechas de inscripcion a cursados que posean el siguiente error: la fecha de inscripcion al cursado de un 
-- alumno es menor a la fecha de inscripcion a la carrera. La nueva fecha que debe tener es la fecha del dia. Se puede hacer en dos pasos, primero
-- realizando la consulta y luego realizando el update manual
UPDATE PUBLIC.INSCRIPCIONES_CURSO
SET FECHAINSCRIPCION = TRUNC(SYSDATE)
WHERE (IDALUMNO, IDCURSO) IN  ( SELECT IC.IDALUMNO, IC.IDCURSO
FROM PUBLIC.INSCRIPCIONES_CURSO IC,
     PUBLIC.CURSO C,
     PUBLIC.INSCRIPCIONES_CARRERA ICA
WHERE IC.IDCURSO = C.IDENTIFICADOR
  AND C.IDCARRERA = ICA.IDCARRERA
  AND IC.IDALUMNO = ICA.IDALUMNO
  AND IC.FECHAINSCRIPCION < ICA.FECHAINSCRIPCION);
--UPDATE COUNT 
--  1 

--- EJERCICIO 7 - COMPLEJIDAD BAJA:  
--INSERTAR un nuevo registro de alumno con tus datos personales, (hacer todos inserts que considera necesario)
INSERT INTO PUBLIC.PERSONA
( IDENTIFICADOR, TIPODOC, DOCUMENTO, NOMBRE, APELLIDO, FECHANAC )
VALUES (6 , 'DNI',27937519 , 'Roberto', 'Cordoba', to_date('11/12/1979','dd/mm/yyyy'));

INSERT INTO PUBLIC.ALUMNO
( IDENTIFICADOR, IDPERSONA, LEGAJO )
VALUES (6 , 6, 27937);

--- EJERCICIO 8 -  COMPLEJIDAD BAJA: 
-- si se desea comenzar a persistir de ahora en mas el dato de direccion de un alumno y considerando que este es un único cambio string de 200 caracteres.
-- Determine sobre que tabla seria mas conveniente persistir esta información y realizar la modificación de estructuras correspondientes.
ALTER TABLE PUBLIC.PERSONA 
ADD DIRECCION VARCHAR(200);

